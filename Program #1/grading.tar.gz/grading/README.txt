This script simply helps you check if your code generates the correct accuracy using sample data.

How to run:

1. Put your sentiment.py and entities.py in this directory.
2. Part A, run: ./partA-grading.sh
3. Part B,
       CS5340 run: ./partB-cs5340-grading.sh
       CS6340 run: ./partB-cs6340-grading.sh

Attention, this grading script is ONLY based on the sample data.

Your program will be graded based on NEW data files.

So please test your program thoroughly to evaluate the generality and correctness of your code!
(Even if your program works perfectly on the sample data that we give you, that does not guarantee that it will work perfectly on new files.)
